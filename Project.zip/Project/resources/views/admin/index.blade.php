@extends('layout/app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">{{ __('Dashboard') }}</div>

                    <div class="card-body">
                        @if (session('status'))
                            <div class="alert alert-success" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif
                        {{ __('You are logged in as a Admin!') }}
                    </div>
                </div>
            </div>
            <div class="col-md-8 justify-content-center">
                <a href="{{route('product.index')}}" class="btn btn-info">Product</a>
            </div>
            <div class="col-md-8 justify-content-center">
                <a href="{{route('category.index')}}" class="btn btn-info">Category</a>
            </div>
            <div class="col-md-8 justify-content-center">
                <a href="{{route('roles.index')}}" class="btn btn-info">Roles</a>
            </div>
        </div>

    </div>
@endsection
