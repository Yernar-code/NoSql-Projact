@extends('layout.app')

@section('content')
<div class="content">
    <div class="container">
        <div class="row mt-3">
            <div class="col-md-12">
                <div class="col-md-12 text-center">
                    <h5>{{$category->name}}</h5>
                </div>
                <p class="text-center mt-5">
                    <a href="{{route('category.index')}}" class="btn btn-primary">GO BACK</a>
                </p>
            </div>
        </div>
    </div>
</div>
@endsection
