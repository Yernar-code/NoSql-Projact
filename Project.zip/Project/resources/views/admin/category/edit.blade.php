@extends('layout.app')

@section('head-content')
    <meta name="csrf-token" content="{{ csrf_token() }}">
@endsection

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex align-items-center">
                        <h2>Edit a category with ID {{$category->id}}</h2>
                        <div class="ml-auto">
                            <a href="{{route('category.index')}}" class="btn btn-outline-secondary">Back to all category</a>
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <form action="{{route('category.update', $category->id)}}" method="post">
                        @csrf
                        @method('PUT')
                        <div class="form-group">
                            <label for="category-name">Category Name</label>
                            <input type="text" value="{{$category->name}}" name="name" id="category-name" class="form-control">
                        </div>
{{--                        <div class="form-group">--}}
{{--                            <label for="product-category">Category</label>--}}
{{--                            <select name="category_id" id="product-category" class="form-control form-control-lg">--}}
{{--                                @foreach($cats as $cat)--}}
{{--                                    @if($cat->id == $product->category->id)--}}
{{--                                        <option value="{{$cat->id}}" selected>{{$cat->name}}</option>--}}
{{--                                    @else--}}
{{--                                        <option value="{{$cat->id}}">{{$cat->name}}</option>--}}
{{--                                    @endif--}}
{{--                                @endforeach--}}
{{--                            </select>--}}
{{--                        </div>--}}
                        <div class="form-group">
                            <button type="submit" class="btn btn-outline-primary btn-lg">Edit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
