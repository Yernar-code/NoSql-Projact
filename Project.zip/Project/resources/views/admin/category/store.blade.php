@extends('layout.app')

@section('content')
<div class="content">
    <div class="container">
        <div class="row mt-3">
            <div class="col-md-12">
                <div class="col-md-12 text-center">
                    <h2>Created category: {{$category}}</h2>
                    <h3>And title: {{$name}}</h3>
                </div>
                <div class="col-md-12">
                    <div class="text-center my-3">
                        <a href="{{route('category.index')}}" class="btn btn-outline-secondary">Back to all categorys</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
