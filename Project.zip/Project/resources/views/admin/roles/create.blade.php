@extends('layout.app')

@section('head-content')
    <meta name="csrf-token" content="{{ csrf_token() }}">
@endsection

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="d-flex align-items-center">
                            <h2>Create a new Roles</h2>
                            <div class="ml-auto">
                                <a href="{{route('roles.index')}}" class="btn btn-outline-secondary">Back to all Roles</a>
                            </div>
                        </div>
                    </div>

                    <div class="card-body">
                        <form action="{{route('roles.store')}}" method="post">
                            @csrf
                            <div class="form-group">
                                <label for="roles-name">Name</label>
                                <input type="text" name="name" id="roles-name" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="roles-price">Display name</label>
                                <input type="text" name="display_name" id="roles-price" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="roles-text">Description</label>
                                <textarea name="description" id="roles-text" cols="30" rows="5" class="form-control"></textarea>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-outline-primary btn-lg">Create</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
