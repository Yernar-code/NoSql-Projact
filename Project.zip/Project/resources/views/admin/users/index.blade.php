@extends('layout.app')

@section('head-content')
<style>
    .form-delete {
        display: inline-block;
    }
</style>
@endsection

@section('content')
        <nav class="container navbar navbar-expand-lg navbar-light bg-light">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                @foreach($roles as $rol)
                    <a class="nav-item nav-link" href="{{route('admin.users.rol', $rol->id)}}">{{$rol->name}}</a>
                @endforeach
                <a class="nav-item nav-link active" href="{{route('users.index')}}">All Role</a>
            </div>
        </div>
        </nav>
        <div class="content">
            <div class="container">
                <div class="row">
                    @if(session('success'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong>Success!</strong> {{ session('success') }}
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    @endif
                </div>
                <div class="row mt-3">
                    <div class="col-md-12">
                        <div class="col-md-12 text-center">
                            <h5>Laravel CRUD tutorial</h5>
                        </div>
                        <div class="col-md-12">
                            <div class="text-center my-3">
                                <a href="{{route('users.create')}}" class="btn btn-outline-secondary">Add new Users</a>
                            </div>
                            <table class="table">
                                <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">User name</th>
                                    <th scope="col">email</th>
                                    <th scope="col">Functions</th>
                                </tr>
                                </thead>
                                <tbody>
                                    @foreach($user as $p)
                                        <tr>
                                            <td>{{$p->id}}</td>
                                            <td>{{$p->name}}</td>                                      {{--https://www.bbc.com/news/uk-54767118--}}
                                            <td>{{$p->email}}</td>
                                            <td><a href="{{route('users.show', $p->id)}}" class="btn btn-info">Read</a>
                                                <a href="{{route('users.edit', $p->id)}}" class="btn btn-success">Edit</a>
                                                <form class="form-delete" action="{{route('users.destroy', $p->id)}}" method="post">
                                                    @method('DELETE')
                                                    @csrf
                                                    <button class="btn btn-danger" onclick="return confirm('Are you sure?')" type="submit">
                                                        Delete
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection
