@extends('layout.app')

@section('head-content')
    <meta name="csrf-token" content="{{ csrf_token() }}">
@endsection

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex align-items-center">
                        <h2>Edit a user with ID {{$user->id}}</h2>
                        <div class="ml-auto">
                            <a href="{{route('users.index')}}" class="btn btn-outline-secondary">Back to all users</a>
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <form action="{{route('users.update', $user->id)}}" method="post">
                        @csrf
                        @method('PUT')
                        <div class="form-group">
                            <label for="user-name">Name</label>
                            <input type="text" value="{{$user->name}}" name="name" id="user-name" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="user-code">email</label>
                            <input type="text" value="{{$user->email}}" name="email" id="user-code" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="product-category">Roles</label>
                            <select name="category_id" id="product-category" class="form-control form-control-lg">
                                @foreach($roles as $rol)
                                    <option value="{{$rol->id}}" selected>{{$rol->name}}</option>
{{--                                    <option value="{{$rol->id}}">{{$rol->name}}</option>--}}
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-outline-primary btn-lg">Edit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
