@extends('layout.app')

@section('head-content')
    <meta name="csrf-token" content="{{ csrf_token() }}">
@endsection

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex align-items-center">
                        <h2>Create a new product</h2>
                        <div class="ml-auto">
                            <a href="{{route('product.index')}}" class="btn btn-outline-secondary">Back to all Products</a>
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <form action="{{route('product.store')}}" method="post">
                        @csrf
                        <div class="form-group">
                            <label for="product-name">Name</label>
                            <input type="text" name="p_name" id="product-name" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="product-code">Product Code</label>
                            <input type="text" name="p_code" id="product-code" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="product-price">Product Price</label>
                            <input type="text" name="price" id="product-price" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="product-text">Description</label>
                            <textarea name="description" id="product-text" cols="30" rows="5" class="form-control"></textarea>
                        </div>


                        <input type="hidden" name="user_id" value="{{\Illuminate\Support\Facades\Auth::id()}}" class="form-control">

                        <div class="product-group">
                            <label for="blog-category">Category</label>
                            <select name="category_id" id="product-category" class="form-control form-control-lg">
                                @foreach($cats as $cat)
                                    <option value="{{$cat->id}}">{{$cat->name}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-outline-primary btn-lg">Create</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
