@extends('layout.app')

@section('head-content')
    <meta name="csrf-token" content="{{ csrf_token() }}">
@endsection

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex align-items-center">
                        <h2>Edit a product with ID {{$product->id}}</h2>
                        <div class="ml-auto">
                            <a href="{{route('product.index')}}" class="btn btn-outline-secondary">Back to all product</a>
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <form action="{{route('product.update', $product->id)}}" method="post">
                        @csrf
                        @method('PUT')
                        <div class="form-group">
                            <label for="product-name">Product Name</label>
                            <input type="text" value="{{$product->p_name}}" name="p_name" id="product-name" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="product-code">Product Code</label>
                            <input type="text" value="{{$product->p_code}}" name="p_code" id="product-code" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="product-price">Product Price</label>
                            <input type="text" value="{{$product->price}}" name="price" id="product-price" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="product-text">Description</label>
                            <textarea name="description" id="product-text" cols="30" rows="5" class="form-control">{{$product->description}}</textarea>
                        </div>
                        <div class="form-group">
                            <label for="product-category">Category</label>
                            <select name="category_id" id="product-category" class="form-control form-control-lg">
                                @foreach($cats as $cat)
                                    @if($cat->id == $product->category->id)
                                        <option value="{{$cat->id}}" selected>{{$cat->name}}</option>
                                    @else
                                        <option value="{{$cat->id}}">{{$cat->name}}</option>
                                    @endif
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-outline-primary btn-lg">Edit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
