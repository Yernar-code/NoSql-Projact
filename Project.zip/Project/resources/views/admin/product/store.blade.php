@extends('layout.app')

@section('content')
<div class="content">
    <div class="container">
        <div class="row mt-3">
            <div class="col-md-12">
                <div class="col-md-12 text-center">
                    <h2>Created product with category: {{$cat}}</h2>
                    <h3>And title: {{$p_name}}</h3>
                    <h3>And text: {{$p_code}}</h3>
                    <h3>And text: {{$price}}</h3>
                    <h3>And text: {{$description}}</h3>
                </div>
                <div class="col-md-12">
                    <div class="text-center my-3">
                        <a href="{{route('product.index')}}" class="btn btn-outline-secondary">Back to all products</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
