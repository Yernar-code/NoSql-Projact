@extends('layouts.app')

@section('head-content')
    <style>
        .form-delete {
            display: inline-block;
        }
    </style>
@endsection

@section('content')
<div class="content">
    @guest
        <nav class="container navbar navbar-expand-lg navbar-light bg-light">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                    @foreach($cats as $cat)
                        <a class="nav-item nav-link" href="{{route('admin.cat', $cat->id)}}">{{$cat->name}}</a>
                    @endforeach
                </div>
            </div>
        </nav>
        <div class="container">
            <table class="table">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Product name</th>
                    <th scope="col">Product code</th>
                    <th scope="col">Product description</th>
                    <th scope="col">Product price</th>
                    <th scope="col">Functions</th>
                </tr>
                </thead>
                <tbody>

                @foreach($Product as $p)
                    <tr>
                        <td>{{$p->id}}</td>
                        <td>{{$p->p_name}}</td>                                      {{--https://www.bbc.com/news/uk-54767118--}}
                        <td>{{$p->p_code}}</td>
                        <td>{{$p->description}}</td>
                        <td>{{$p->price}}</td>
                        <td><a href="{{route('show', $p->id)}}" class="btn btn-info">Read</a>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>

    @else
        <nav class="container navbar navbar-expand-lg navbar-light bg-light">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                    @foreach($cats as $cat)
                        <a class="nav-item nav-link" href="{{route('admin.cat', $cat->id)}}">{{$cat->name}}</a>
                    @endforeach
                    {{--                    <a class="nav-item nav-link active" href="#">Home</a>--}}
                    {{--                    <a class="nav-item nav-link" href="#">Features</a>--}}
                </div>
            </div>
        </nav>
        <div class="container">
            <table class="table">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Product name</th>
                    <th scope="col">Product code</th>
                    <th scope="col">Product description</th>
                    <th scope="col">Product price</th>
                    <th scope="col">Functions</th>
                </tr>
                </thead>
                <tbody>

                @foreach($Product as $p)
                    <tr>
                        <td>{{$p->id}}</td>
                        <td>{{$p->p_name}}</td>                                      {{--https://www.bbc.com/news/uk-54767118--}}
                        <td>{{$p->p_code}}</td>
                        <td>{{$p->description}}</td>
                        <td>{{$p->price}}</td>
                        <td><a href="{{route('show', $p->id)}}" class="btn btn-info">Read</a>
                            <a href="{{route('basket', $p->id)}}" class="btn btn-success">Add</a>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    @endguest
</div>
@endsection
