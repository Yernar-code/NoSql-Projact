<?php $__env->startSection('head-content'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="d-flex align-items-center">
                            <h2>Edit a role with ID <?php echo e($role->id); ?></h2>
                            <div class="ml-auto">
                                <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-outline-secondary">Back to all Roles</a>
                            </div>
                        </div>
                    </div>

                    <div class="card-body">
                        <form action="<?php echo e(route('roles.update', $role->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group">
                                <label for="role-name">Name/Code</label>

                                <span class="form-control" name="name" id="role-name"><?php echo e($role->name); ?></span>
                            </div>
                            <div class="form-group">
                                <label for="role-display_name">Display Name:</label>
                               <input type="text" value="<?php echo e($role->display_name); ?>" name="display_name" id="role-display_name" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="role-text">Description</label>
                                <textarea name="description" id="role-text" cols="30" rows="5" class="form-control"><?php echo e($role->description); ?></textarea>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-outline-primary btn-lg">Edit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ernar\Desktop\lara\Project\resources\views/admin/roles/edit.blade.php ENDPATH**/ ?>