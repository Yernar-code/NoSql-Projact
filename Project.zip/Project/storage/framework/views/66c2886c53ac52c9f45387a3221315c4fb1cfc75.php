<?php $__env->startSection('head-content'); ?>
    <style>
        .form-delete {
            display: inline-block;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', 'Купон ' . $coupon->code); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
    <div class="col-md-12">
        <h1><?php echo e($coupon->code); ?></h1>
        <table class="table">
            <tbody>
            <tr>
                <th>
                    Поле
                </th>
                <th>
                    Значение
                </th>
            </tr>
            <tr>
                <td>ID</td>
                <td><?php echo e($coupon->id); ?></td>
            </tr>
            <tr>
                <td>Код</td>
                <td><?php echo e($coupon->code); ?></td>
            </tr>
            <tr>
                <td>Описание</td>
                <td><?php echo e($coupon->description); ?></td>
            </tr>
            <tr>
                <td>Абсолютное значенин</td>
                <td><?php if($coupon->isAbsolute()): ?> Да <?php else: ?> Нет <?php endif; ?></td>
            </tr>
            <tr>
                <td>
                    Скидка
                </td>
                <td>
                    <?php echo e($coupon->value); ?> <?php if($coupon->isAbsolute()): ?> <?php echo e($coupon->currency->code); ?> <?php else: ?> % <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td>Использовать один раз</td>
                <td><?php if($coupon->isOnlyOnce()): ?> Да <?php else: ?> Нет <?php endif; ?></td>
            </tr>
            <tr>
                <td>Использован:</td>
                <td><?php echo e($coupon->orders->count()); ?></td>
            </tr>
            <?php if($coupon->expired_at): ?>
                <tr>
                    <td>Действителен до:</td>
                    <td><?php echo e($coupon->expired_at->format('d.m.Y')); ?></td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ernar\Desktop\lara\Project\resources\views/admin/coupons/show.blade.php ENDPATH**/ ?>