<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container">
        <div class="row mt-3">
            <div class="col-md-12">
                <div class="col-md-12 text-center">
                    <h5><?php echo e($product->p_name); ?></h5>
                </div>
                <div class="col-md-6 offset-3 mt-5">
                    <?php echo e($product->p_code); ?>

                </div>
                <div class="col-md-6 offset-3 mt-5">
                    <?php echo e($product->description); ?>

                </div>
                <div class="col-md-6 offset-3 mt-5">
                    <?php echo e($product->price); ?>

                </div>
                <div class="col-md-6 offset-6 mt-5">
                    <b>Author:</b> <?php echo e($product->user->name); ?>

                </div>
                <p class="text-center mt-5">
                    <a href="<?php echo e(route('product.index')); ?>" class="btn btn-primary">GO BACK</a>
                </p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ernar\Desktop\lara\Project\resources\views/admin/product/show.blade.php ENDPATH**/ ?>