<?php $__env->startSection('head-content'); ?>
<style>
    .form-delete {
        display: inline-block;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <nav class="container navbar navbar-expand-lg navbar-light bg-light">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">







        </div>
    </nav>
    <div class="content">
        <div class="container">
            <div class="row">
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>Success!</strong> <?php echo e(session('success')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
            </div>

            <div class="row mt-3">
                <div class="col-md-12">
                    <div class="col-md-12 text-center">
                        <h5>Laravel CRUD tutorial</h5>
                    </div>
                    <div class="col-md-12">
                        <div class="text-center my-3">
                            <a href="<?php echo e(route('category.create')); ?>" class="btn btn-outline-secondary">Create new Category</a>
                        </div>
                        <table class="table">
                            <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Category name</th>
                                <th scope="col">Functions</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($c->id); ?></td>
                                        <td><?php echo e($c->name); ?></td>
                                        <td><a href="<?php echo e(route('category.show', $c->id)); ?>" class="btn btn-info">Read</a>
                                            <a href="<?php echo e(route('category.edit', $c->id)); ?>" class="btn btn-success">Edit</a>
                                            <form class="form-delete" action="<?php echo e(route('category.destroy', $c->id)); ?>" method="post">
                                                <?php echo method_field('DELETE'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button class="btn btn-danger" onclick="return confirm('Are you sure?')" type="submit">
                                                    Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ernar\Desktop\lara\Project\resources\views/admin/category/index.blade.php ENDPATH**/ ?>
