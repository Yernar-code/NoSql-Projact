<?php $__env->startSection('title', "Role details"); ?>

<?php $__env->startSection('content'); ?>
  <div>
  </div>
  <div class="container flex flex-col">
    <div class="-my-2 py-2 overflow-x-auto sm:-mx-6 sm:px-6 lg:-mx-8 lg:px-32">
      <div
        class="align-middle inline-block min-w-full shadow overflow-hidden sm:rounded-lg border-b border-gray-200 p-8"
      >
        <label class="flex justify-between w-4/12">
          <span class="text-gray-900 font-bold">Name/Code:</span>
          <span class="ml-4 text-gray-800"><?php echo e($role->name); ?></span>
        </label>

        <label class="flex justify-between w-4/12 my-4">
          <span class="text-gray-900 font-bold">Display Name:</span>
          <span class="ml-4 text-gray-800"><?php echo e($role->display_name); ?></span>
        </label>

        <label class="flex justify-between w-4/12 my-4">
          <span class="text-gray-900 font-bold">Description:</span>
          <span class="ml-4 text-gray-800"><?php echo e($role->description); ?></span>
        </label>







          <a
            href="<?php echo e(route("roles.index")); ?>"
            class="text-blue-600 hover:text-blue-900"
          >
            Back
          </a>
        </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ernar\Desktop\lara\Project\resources\views/admin/roles/show.blade.php ENDPATH**/ ?>