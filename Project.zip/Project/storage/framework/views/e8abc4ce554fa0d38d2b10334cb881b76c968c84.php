<?php $__env->startSection('head-content'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex align-items-center">
                        <h2>Edit a category with ID <?php echo e($category->id); ?></h2>
                        <div class="ml-auto">
                            <a href="<?php echo e(route('category.index')); ?>" class="btn btn-outline-secondary">Back to all category</a>
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <form action="<?php echo e(route('category.update', $category->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group">
                            <label for="category-name">Category Name</label>
                            <input type="text" value="<?php echo e($category->name); ?>" name="name" id="category-name" class="form-control">
                        </div>












                        <div class="form-group">
                            <button type="submit" class="btn btn-outline-primary btn-lg">Edit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ernar\Desktop\lara\Project\resources\views/admin/category/edit.blade.php ENDPATH**/ ?>