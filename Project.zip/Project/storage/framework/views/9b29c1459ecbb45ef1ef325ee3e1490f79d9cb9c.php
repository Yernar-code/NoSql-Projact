<?php $__env->startSection('head-content'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex align-items-center">
                        <h2>Edit a user with ID <?php echo e($user->id); ?></h2>
                        <div class="ml-auto">
                            <a href="<?php echo e(route('users.index')); ?>" class="btn btn-outline-secondary">Back to all users</a>
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <form action="<?php echo e(route('users.update', $user->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group">
                            <label for="user-name">Name</label>
                            <input type="text" value="<?php echo e($user->name); ?>" name="name" id="user-name" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="user-code">email</label>
                            <input type="text" value="<?php echo e($user->email); ?>" name="email" id="user-code" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="product-category">Roles</label>
                            <select name="category_id" id="product-category" class="form-control form-control-lg">
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($rol->id); ?>" selected><?php echo e($rol->name); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-outline-primary btn-lg">Edit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ernar\Desktop\lara\Project\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>