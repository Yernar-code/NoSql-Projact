<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <?php echo e(__('You are logged in as a Admin!')); ?>

                    </div>
                </div>
            </div>
            <div class="col-md-8 justify-content-center">
                <a href="<?php echo e(route('product.index')); ?>" class="btn btn-info">Product</a>
            </div>
            <div class="col-md-8 justify-content-center">
                <a href="<?php echo e(route('category.index')); ?>" class="btn btn-info">Category</a>
            </div>
            <div class="col-md-8 justify-content-center">
                <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-info">Roles</a>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ernar\Desktop\lara\Project\resources\views/admin/index.blade.php ENDPATH**/ ?>
