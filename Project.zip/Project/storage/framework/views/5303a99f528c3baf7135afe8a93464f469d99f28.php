<?php $__env->startSection('head-content'); ?>
<style>
    .form-delete {
        display: inline-block;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <nav class="container navbar navbar-expand-lg navbar-light bg-light">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="nav-item nav-link" href="<?php echo e(route('admin.product.cat', $cat->id)); ?>"><?php echo e($cat->name); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <a class="nav-item nav-link active" href="<?php echo e(route('product.index')); ?>">All Product</a>
            </div>
        </div>
        </nav>
        <div class="content">
            <div class="container">
                <div class="row">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong>Success!</strong> <?php echo e(session('success')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="row mt-3">
                    <div class="col-md-12">
                        <div class="col-md-12 text-center">
                            <h5>Laravel CRUD tutorial</h5>
                        </div>
                        <div class="col-md-12">
                            <div class="text-center my-3">
                                <a href="<?php echo e(route('product.create')); ?>" class="btn btn-outline-secondary">Create new Product</a>
                            </div>
                            <table class="table">
                                <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Product name</th>
                                    <th scope="col">Product code</th>
                                    <th scope="col">Product description</th>
                                    <th scope="col">Product price</th>
                                    <th scope="col">Functions</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($p->id); ?></td>
                                            <td><?php echo e($p->p_name); ?></td>
                                            <td><?php echo e($p->p_code); ?></td>
                                            <td><?php echo e($p->description); ?></td>
                                            <td><?php echo e($p->price); ?></td>
                                            <td><a href="<?php echo e(route('product.show', $p->id)); ?>" class="btn btn-info">Read</a>
                                                <a href="<?php echo e(route('product.edit', $p->id)); ?>" class="btn btn-success">Edit</a>
                                                <form class="form-delete" action="<?php echo e(route('product.destroy', $p->id)); ?>" method="post">
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button class="btn btn-danger" onclick="return confirm('Are you sure?')" type="submit">
                                                        Delete
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ernar\Desktop\lara\Project\resources\views/admin/product/index.blade.php ENDPATH**/ ?>
