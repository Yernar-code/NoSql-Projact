<?php $__env->startSection('head-content'); ?>
<style>
    .form-delete {
        display: inline-block;
    }

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container flex flex-col">
    <div class="row mt-3">
        <div class="col-md-12">
          <div class="text-center my-3">
              <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-outline-secondary">Create new Roles</a>
          </div>
          <table class="table">
              <thead>
                <tr>
                  <th class="th">Id</th>
                  <th class="th">Display Name</th>
                  <th class="th">Name</th>
                  <th class="th">Function</th>
                </tr>
              </thead>
              <tbody class="bg-white">
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="td text-sm leading-5 text-gray-900">
                    <?php echo e($role->id); ?>

                  </td>
                  <td class="td text-sm leading-5 text-gray-900">
                    <?php echo e($role->display_name); ?>

                  </td>
                  <td class="td text-sm leading-5 text-gray-900">
                    <?php echo e($role->name); ?>

                  </td>
                  <td class="flex justify-end px-6 py-4 whitespace-no-wrap text-right border-b border-gray-200 text-sm leading-5 font-medium">
                    <a href="<?php echo e(route('roles.edit', $role->id)); ?>" class="text-blue-600 hover:text-blue-900">Edit</a>
                    <a href="<?php echo e(route('roles.show', $role->id)); ?>" class="text-blue-600 hover:text-blue-900">Details</a>
                    <form
                      action="<?php echo e(route('roles.destroy', $role->id)); ?>"
                      method="POST"
                      onsubmit="return confirm('Are you sure you want to delete the record?');"
                    >
                      <?php echo method_field('DELETE'); ?>
                      <?php echo csrf_field(); ?>
                      <button
                        type="submit"
                        class="<?php echo e(\Laratrust\Helper::roleIsDeletable($role) ? 'text-red-600 hover:text-red-900' : 'text-gray-600 hover:text-gray-700 cursor-not-allowed'); ?> ml-4"
                        <?php if(!\Laratrust\Helper::roleIsDeletable($role)): ?> disabled <?php endif; ?>
                      >Delete</button>
                    </form>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
          </table>
        </div>
    </div>
  </div>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ernar\Desktop\lara\Project\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>