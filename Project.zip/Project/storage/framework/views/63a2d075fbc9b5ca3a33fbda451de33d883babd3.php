<?php $__env->startSection('head-content'); ?>
    <style>
        .form-delete {
            display: inline-block;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php if(isset($coupon)): ?>
    <?php $__env->startSection('title', 'Редактировать купон ' . $coupon->name); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Создать купон'); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
    <div class="col-md-12">
        <?php if(isset($coupon)): ?>
            <h1>Редактировать купон</h1>
        <?php else: ?>
            <h1>Добавить купон</h1>
        <?php endif; ?>
        <form method="POST"
              <?php if(isset($coupon)): ?>
              action="<?php echo e(route('coupons.update', $coupon)); ?>"
              <?php else: ?>
              action="<?php echo e(route('coupons.store')); ?>"
            <?php endif; ?>
        >
            <div>
                <?php if(isset($coupon)): ?>
                    <?php echo method_field('PUT'); ?>
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                <div class="input-group row">
                    <label for="code" class="col-sm-2 col-form-label">Код: </label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" name="code" id="code"
                               value="<?php if(isset($coupon)): ?><?php echo e($coupon->code); ?><?php endif; ?>">
                    </div>
                </div>
                <br>
                <div class="input-group row">
                    <label for="value" class="col-sm-2 col-form-label">Номинал: </label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" name="value" id="value"
                               value="<?php if(isset($coupon)): ?><?php echo e($coupon->value); ?><?php endif; ?>">
                    </div>
                </div>
                <?php $__currentLoopData = [
                'type' => 'Абсолютное значение',
                'only_once' => 'Купон может быть использован только один раз',
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group row">
                        <label for="code" class="col-sm-2 col-form-label"><?php echo e($title); ?>: </label>
                        <div class="col-sm-10">
                            <input type="checkbox" name="<?php echo e($field); ?>" id="<?php echo e($field); ?>"
                                   <?php if(isset($coupon) && $coupon->$field === 1): ?>
                                   checked="'checked"
                                <?php endif; ?>
                            >
                        </div>
                    </div>
                    <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <br>
                <div class="input-group row">
                    <label for="expired_at" class="col-sm-2 col-form-label">Использовать до: </label>
                    <div class="col-sm-6">
                        <input type="date" class="form-control" name="expired_at" id="expired_at"
                               value="<?php if(isset($coupon) && !is_null($coupon->expired_at)): ?>
                               <?php echo e($coupon->expired_at->format('Y-m-d')); ?><?php endif; ?>">
                    </div>
                </div>
                <br>
                <div class="input-group row">
                    <label for="description" class="col-sm-2 col-form-label">Описание: </label>
                    <div class="col-sm-6">
                        <textarea name="description" id="description" cols="72"
                                  rows="7"><?php if(isset($coupon)): ?><?php echo e($coupon->description); ?><?php endif; ?></textarea>
                    </div>
                </div>
                <br>
                <button class="btn btn-success">Сохранить</button>
            </div>
        </form>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ernar\Desktop\lara\Project\resources\views/admin/coupons/form.blade.php ENDPATH**/ ?>