<?php $__env->startSection('head-content'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex align-items-center">
                        <h2>Create a new product</h2>
                        <div class="ml-auto">
                            <a href="<?php echo e(route('product.index')); ?>" class="btn btn-outline-secondary">Back to all Products</a>
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <form action="<?php echo e(route('product.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="product-name">Name</label>
                            <input type="text" name="p_name" id="product-name" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="product-code">Product Code</label>
                            <input type="text" name="p_code" id="product-code" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="product-price">Product Price</label>
                            <input type="text" name="price" id="product-price" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="product-text">Description</label>
                            <textarea name="description" id="product-text" cols="30" rows="5" class="form-control"></textarea>
                        </div>


                        <input type="hidden" name="user_id" value="<?php echo e(\Illuminate\Support\Facades\Auth::id()); ?>" class="form-control">

                        <div class="product-group">
                            <label for="blog-category">Category</label>
                            <select name="category_id" id="product-category" class="form-control form-control-lg">
                                <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-outline-primary btn-lg">Create</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ernar\Desktop\lara\Project\resources\views/admin/users/create.blade.php ENDPATH**/ ?>