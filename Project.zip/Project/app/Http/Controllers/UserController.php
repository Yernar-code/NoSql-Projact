<?php

namespace App\Http\Controllers;

use App\Models\Role;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware('role:user|superadministrator|administrator');
        $this->rolesModel = Config::get('laratrust.models.role');
    }

    public function users()
    {
        return view('user.index');
    }

    public function index()
    {
        $user = User::all();
        $roles = Role::all();
        return view('admin.users.index', compact(['user', 'roles']));
    }

    public function usersByRole(Role $role){
        $roles = Role::all();
        $user = DB::table('users')->select('users.name', 'roles.name')->join('role_user', 'role_user.user_id', '=', 'users.id')->where('roles.name')->get();
        return view('admin.users.index', compact(['user', 'roles']));
    }

    public function create()
    {
        $roles = Role::all();
        return view('admin.users.create',compact('roles'));
    }

    public function show(User $user)
    {
        $roles = Role::all();
        return view('admin.users.show',compact(['user','roles']));
    }

    public function store(Request $request)
    {
        $user = new User();
        $role = new Role();
        $user->name = $request->input('name');
        $user->email = $request->input('email');
        $role->role_id = $request->input('role_id');
        $user->save();
        $role->save();

        return redirect()->route('users.index')->with('success', "Your question has been saved");
    }

    public function edit(User $user)
    {
        $roles = Role::all();
        return view('admin.users.edit',compact(['user','roles']));
    }

    public function update(Request $request, User $user,Role $role)
    {
        $user->update($request->only('name', 'email', 'password','role_id'));
        return redirect()->route('users.index')->with('success',"Your user is update");
    }

    public function destroy(User $user)
    {
        $user->delete();
        return redirect()->route('users.index')->with('success',"Your user is deleted");
    }
    public function giveRole(){
        $user = User::get();
        return view('admin.users.index', compact('user'));
    }

    public function giveRoleGet($user_id, $role_id){
        $user = User::find($user_id);
        $user->roles()->attach($role_id);
        return redirect()->route('admin.give_role_get');
    }
}
