<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;

class MainController extends Controller
{
    public function index(){
        $Product = Product::all();
        $cats = Category::all();
        return view('index', compact(['Product','cats']));
    }
    public function productsByCat(Category $category){
        $cats = Category::all();
        $Product = Product::where('category_id', $category->id)->get();

        return view('index', compact(['Product', 'cats']));
    }
    public function show(product $product)
    {
        return view('show',compact('product'));
    }
}
