<?php

namespace App\Models;

use Illuminate\Support\Facades\Config;
use Laratrust\Models\LaratrustRole;

class Role extends LaratrustRole
{
    public function __construct(array $attributes = [])
    {
        parent::__construct($attributes);
        $this->table = Config::get('laratrust.tables.roles');
    }
    protected $fillable = [
        'name',
        'display_name',
        'description',
    ];

    public function users()
    {
        return $this->belongsToMany('App\Models\User');
    }

}
